function Add_Products()
  	{
  		var add=document.getElementById('add_products');
  		var remove=document.getElementById('remove_products');
  		var see=document.getElementById('see_products');
  		var update=document.getElementById('update_products');
  		if(add.style.display==="none")
  		{
  			add.style.display="block";
  			remove.style.display="none";
  			see.style.display="none";
  			update.style.display="none";
  		}
  		else
  		{
  			add.style.display="block";
  			remove.style.display="none";
  			see.style.display="none";
  			update.style.display="none";
  		}
  	}
  	function Remove_Products()
  	{
  		var add=document.getElementById('add_products');
  		var remove=document.getElementById('remove_products');
  		var see=document.getElementById('see_products');
  		var update=document.getElementById('update_products');
  		if(remove.style.display==="none")
  		{
  			remove.style.display="block";
  			add.style.display="none";
  			see.style.display="none";
  			update.style.display="none";
  		}
  		else
  		{
  			remove.style.display="block";
  			add.style.display="none";
  			see.style.display="none";
  			update.style.display="none";
  		}
  	}
  	function See_Products()
  	{
  		var add=document.getElementById('add_products');
  		var remove=document.getElementById('remove_products');
  		var see=document.getElementById('see_products');
  		var update=document.getElementById('update_products');
  		if(see.style.display==="none")
  		{
  			see.style.display="block";
  			add.style.display="none";
  			remove.style.display="none";
  			update.style.display="none";
  		}
  		else
  		{
  			see.style.display="block";
  			add.style.display="none";
  			remove.style.display="none";
  			update.style.display="none";
  		}
  	}
  	function Update_Products()
  	{
  		var add=document.getElementById('add_products');
  		var remove=document.getElementById('remove_products');
  		var see=document.getElementById('see_products');
  		var update=document.getElementById('update_products');
  		if(remove.style.display==="none")
  		{
  			update.style.display="block";
  			add.style.display="none";
  			remove.style.display="none";
  			see.style.display="none";

  		}
  		else
  		{
  			update.style.display="block";
  			add.style.display="none";
  			remove.style.display="none";
  			see.style.display="none";
  		}
  	}